exports.id = 45;
exports.ids = [45];
exports.modules = {

/***/ 5635:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Grand_Hotel_059969', '__Grand_Hotel_Fallback_059969'","fontWeight":400,"fontStyle":"normal"},
	"className": "__className_059969"
};


/***/ }),

/***/ 7774:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Parisienne_d36443', '__Parisienne_Fallback_d36443'","fontWeight":400,"fontStyle":"normal"},
	"className": "__className_d36443"
};


/***/ }),

/***/ 2114:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Alex_Brush_3f6018', '__Alex_Brush_Fallback_3f6018'","fontWeight":400,"fontStyle":"normal"},
	"className": "__className_3f6018"
};


/***/ }),

/***/ 7528:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Cormorant_4170c5', '__Cormorant_Fallback_4170c5'","fontStyle":"normal"},
	"className": "__className_4170c5"
};


/***/ }),

/***/ 4701:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Poppins_29995e', '__Poppins_Fallback_29995e'"},
	"className": "__className_29995e"
};


/***/ }),

/***/ 2599:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Grand_Hotel_059969', '__Grand_Hotel_Fallback_059969'","fontWeight":400,"fontStyle":"normal"},
	"className": "__className_059969"
};


/***/ }),

/***/ 7101:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Poppins_29995e', '__Poppins_Fallback_29995e'"},
	"className": "__className_29995e"
};


/***/ }),

/***/ 741:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Grand_Hotel_059969', '__Grand_Hotel_Fallback_059969'","fontWeight":400,"fontStyle":"normal"},
	"className": "__className_059969"
};


/***/ }),

/***/ 4241:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Grand_Hotel_059969', '__Grand_Hotel_Fallback_059969'","fontWeight":400,"fontStyle":"normal"},
	"className": "__className_059969"
};


/***/ }),

/***/ 6118:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Cormorant_4170c5', '__Cormorant_Fallback_4170c5'","fontStyle":"normal"},
	"className": "__className_4170c5"
};


/***/ }),

/***/ 2801:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Grand_Hotel_059969', '__Grand_Hotel_Fallback_059969'","fontWeight":400,"fontStyle":"normal"},
	"className": "__className_059969"
};


/***/ }),

/***/ 945:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Poppins_29995e', '__Poppins_Fallback_29995e'"},
	"className": "__className_29995e"
};


/***/ }),

/***/ 2307:
/***/ (() => {



/***/ }),

/***/ 7724:
/***/ (() => {



/***/ }),

/***/ 2287:
/***/ (() => {



/***/ }),

/***/ 5563:
/***/ (() => {



/***/ }),

/***/ 8299:
/***/ (() => {



/***/ }),

/***/ 3527:
/***/ (() => {



/***/ }),

/***/ 7830:
/***/ (() => {



/***/ }),

/***/ 8819:
/***/ (() => {



/***/ })

};
;